import React from 'react';
import { render } from 'react-dom';
import App from './App';
render( /*#__PURE__*/React.createElement(App, null), document.getElementById('root'));